<?php include 'includes/header.php'; ?>

    <main class="container mx-auto my-10 p-6 bg-white rounded-xl shadow-lg">
        <h1 class="text-4xl font-bold text-center text-blue-800 mb-8">हाम्रा शैक्षिक कार्यक्रमहरू</h1>

        <section class="mb-10">
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">पूर्व-प्राथमिक शिक्षा (नर्सरी - KG)</h2>
            <div class="flex flex-col md:flex-row items-center md:space-x-8">
                <img src="https://placehold.co/400x250/F0F8FF/000000?text=Early+Childhood" alt="Early Childhood Education" class="w-full md:w-1/2 rounded-lg shadow-md mb-6 md:mb-0">
                <p class="text-gray-700 text-lg leading-relaxed">
                    हाम्रो पूर्व-प्राथमिक कार्यक्रमले साना बालबालिकाहरूको लागि सुरक्षित, हेरचाह गर्ने र उत्तेजक वातावरण प्रदान गर्दछ। खेल-आधारित सिकाइ विधिहरू मार्फत, हामी उनीहरूको सामाजिक, भावनात्मक, शारीरिक र संज्ञानात्मक विकासलाई प्रोत्साहन गर्छौं।
                </p>
            </div>
            <ul class="list-disc list-inside text-gray-700 text-base mt-4 space-y-2">
                <li>रचनात्मक खेल र गतिविधिहरू</li>
                <li>आधारभूत संख्या र अक्षर ज्ञान</li>
                <li>सामाजिक अन्तरक्रिया र भावनात्मक विकास</li>
                <li>शारीरिक समन्वय र मोटर कौशल विकास</li>
            </ul>
        </section>

        <section class="mb-10">
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">प्राथमिक शिक्षा (कक्षा १ - ५)</h2>
            <div class="flex flex-col md:flex-row items-center md:space-x-8">
                <img src="https://placehold.co/400x250/FFFACD/000000?text=Primary+Education" alt="Primary Education" class="w-full md:w-1/2 rounded-lg shadow-md mb-6 md:mb-0">
                <p class="text-gray-700 text-lg leading-relaxed">
                    प्राथमिक शिक्षामा, हामी विद्यार्थीहरूलाई बलियो शैक्षिक आधार प्रदान गर्दछौं। पाठ्यक्रमले भाषा, गणित, विज्ञान र सामाजिक अध्ययनका आधारभूत अवधारणाहरूमा केन्द्रित गर्दछ, साथै उनीहरूको आलोचनात्मक सोच र समस्या समाधान गर्ने क्षमतालाई प्रोत्साहित गर्दछ।
                </p>
            </div>
            <ul class="list-disc list-inside text-gray-700 text-base mt-4 space-y-2">
                <li>नेपाली र अंग्रेजी भाषामा दक्षता</li>
                <li>गणितीय अवधारणाहरूको विकास</li>
                <li>विज्ञान र प्रविधिमा प्रारम्भिक परिचय</li>
                <li>कला, संगीत र खेलकुदका अतिरिक्त क्रियाकलापहरू</li>
            </ul>
        </section>

        <section class="mb-10">
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">माध्यमिक शिक्षा (कक्षा ६ - १०)</h2>
            <div class="flex flex-col md:flex-row items-center md:space-x-8">
                <img src="https://placehold.co/400x250/DDA0DD/000000?text=Secondary+Education" alt="Secondary Education" class="w-full md:w-1/2 rounded-lg shadow-md mb-6 md:mb-0">
                <p class="text-gray-700 text-lg leading-relaxed">
                    माध्यमिक शिक्षा कार्यक्रमले विद्यार्थीहरूलाई उच्च शिक्षा र भविष्यको करियरका लागि तयार गर्दछ। हामी विस्तृत पाठ्यक्रम, अनुभवी शिक्षकहरू र आधुनिक सिकाइ स्रोतहरू प्रदान गर्दछौं ताकि विद्यार्थीहरूले आफ्नो पूर्ण क्षमता हासिल गर्न सकून्।
                </p>
            </div>
            <ul class="list-disc list-inside text-gray-700 text-base mt-4 space-y-2">
                <li>विज्ञान, व्यवस्थापन र मानविकी संकायमा तयारी</li>
                <li>प्रोजेक्ट-आधारित सिकाइ र अनुसन्धान</li>
                <li>नेतृत्व विकास र सार्वजनिक बोल्ने सीप</li>
                <li>करियर परामर्श र मार्गदर्शन</li>
            </ul>
        </section>

        <section>
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">अतिरिक्त क्रियाकलापहरू</h2>
            <p class="text-gray-700 text-lg leading-relaxed mb-4">
                शैक्षिक उत्कृष्टताका साथै, हामी विद्यार्थीहरूको सर्वांगीण विकासका लागि विभिन्न अतिरिक्त क्रियाकलापहरू पनि प्रदान गर्दछौं:
            </p>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div class="bg-blue-50 p-6 rounded-lg shadow-md">
                    <h3 class="font-semibold text-xl text-blue-700 mb-2">खेलकुद</h3>
                    <p class="text-gray-600">फुटबल, बास्केटबल, भलिबल, क्रिकेट, ब्याडमिन्टन, टेबल टेनिस आदि।</p>
                </div>
                <div class="bg-green-50 p-6 rounded-lg shadow-md">
                    <h3 class="font-semibold text-xl text-green-700 mb-2">कला र संस्कृति</h3>
                    <p class="text-gray-600">चित्रकला, संगीत, नृत्य, नाटक, हस्तकला आदि।</p>
                </div>
                <div class="bg-purple-50 p-6 rounded-lg shadow-md">
                    <h3 class="font-semibold text-xl text-purple-700 mb-2">क्लबहरू</h3>
                    <p class="text-gray-600">विज्ञान क्लब, साहित्य क्लब, वादविवाद क्लब, वातावरण क्लब आदि।</p>
                </div>
            </div>
        </section>
    </main>

<?php include 'includes/footer.php'; ?>
