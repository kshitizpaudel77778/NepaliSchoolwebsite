<?php
include 'includes/header.php';
include 'includes/db_connect.php';
?>

    <main class="container mx-auto my-10 p-6 bg-white rounded-xl shadow-lg">
        <h1 class="text-4xl font-bold text-center text-blue-800 mb-8">हाम्रा शिक्षक तथा कर्मचारीहरू</h1>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php
            $sql = "SELECT name, position, subject, bio, image_url FROM teachers ORDER BY name ASC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<div class="bg-gray-50 p-6 rounded-lg shadow-md flex flex-col items-center text-center hover:shadow-xl transition-shadow duration-300">';
                    echo '<img src="' . htmlspecialchars($row["image_url"]) . '" alt="' . htmlspecialchars($row["name"]) . '" class="w-32 h-32 object-cover rounded-full mb-4 border-4 border-blue-300" onerror="this.onerror=null;this.src=\'https://placehold.co/128x128/ccc/333?text=No+Photo\';">';
                    echo '<h3 class="text-2xl font-semibold text-blue-700 mb-1">' . htmlspecialchars($row["name"]) . '</h3>';
                    echo '<p class="text-gray-600 text-lg font-medium mb-2">' . htmlspecialchars($row["position"]) . '</p>';
                    if (!empty($row["subject"])) {
                        echo '<p class="text-gray-500 text-md mb-3">विषय: ' . htmlspecialchars($row["subject"]) . '</p>';
                    }
                    echo '<p class="text-gray-700 text-base leading-relaxed">' . htmlspecialchars($row["bio"]) . '</p>';
                    echo '</div>';
                }
            } else {
                echo '<p class="col-span-full text-center text-gray-600">कुनै शिक्षक तथा कर्मचारीको विवरण उपलब्ध छैन।</p>';
            }
            $conn->close();
            ?>
        </div>
    </main>

<?php include 'includes/footer.php'; ?>
