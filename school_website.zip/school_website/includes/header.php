<!DOCTYPE html>
<html lang="ne">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>हाम्रो विद्यालय</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts - Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f0f4f8; /* Light gray background */
        }
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://placehold.co/1200x600/3B82F6/FFFFFF?text=School+Building') no-repeat center center/cover;
            min-height: 60vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }
        .slideshow-container {
            position: relative;
            max-width: 1000px;
            margin: auto;
            overflow: hidden;
            border-radius: 0.75rem; /* rounded-xl */
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); /* shadow-lg */
        }
        .mySlides {
            display: none;
        }
        .mySlides img {
            width: 100%;
            height: auto;
            display: block;
        }
        .prev, .next {
            cursor: pointer;
            position: absolute;
            top: 50%;
            width: auto;
            padding: 16px;
            margin-top: -22px;
            color: white;
            font-weight: bold;
            font-size: 18px;
            transition: 0.6s ease;
            border-radius: 0 3px 3px 0;
            user-select: none;
            background-color: rgba(0,0,0,0.5);
        }
        .next {
            right: 0;
            border-radius: 3px 0 0 3px;
        }
        .prev:hover, .next:hover {
            background-color: rgba(0,0,0,0.8);
        }
        .dot {
            cursor: pointer;
            height: 15px;
            width: 15px;
            margin: 0 2px;
            background-color: #bbb;
            border-radius: 50%;
            display: inline-block;
            transition: background-color 0.6s ease;
        }
        .active-dot {
            background-color: #717171;
        }
        .fade {
            animation-name: fade;
            animation-duration: 1.5s;
        }
        @keyframes fade {
            from {opacity: .4}
            to {opacity: 1}
        }
        /* Mobile menu specific styles */
        .mobile-menu-overlay {
            display: none; /* Hidden by default */
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 40; /* Above navbar */
        }
        .mobile-menu {
            position: fixed;
            top: 0;
            right: -100%; /* Start off-screen */
            width: 75%;
            max-width: 300px;
            height: 100%;
            background-color: #ffffff;
            z-index: 50;
            transition: right 0.3s ease-in-out;
            box-shadow: -5px 0 15px rgba(0,0,0,0.2);
            padding: 1.5rem;
            overflow-y: auto;
        }
        .mobile-menu.open {
            right: 0;
        }
    </style>
</head>
<body class="bg-gray-100 text-gray-900">
    <!-- Navbar -->
    <nav class="bg-blue-700 p-4 shadow-md sticky top-0 z-30">
        <div class="container mx-auto flex justify-between items-center">
            <a href="index.php" class="text-white text-2xl font-bold rounded-md hover:text-blue-200 transition duration-300">हाम्रो विद्यालय</a>
            <!-- Desktop Menu -->
            <div class="hidden md:flex space-x-6">
                <a href="index.php" class="text-white hover:text-blue-200 transition duration-300 p-2 rounded-md">गृहपृष्ठ</a>
                <a href="about.php" class="text-white hover:text-blue-200 transition duration-300 p-2 rounded-md">हाम्रो बारेमा</a>
                <a href="programs.php" class="text-white hover:text-blue-200 transition duration-300 p-2 rounded-md">कार्यक्रमहरू</a>
                <a href="teachers.php" class="text-white hover:text-blue-200 transition duration-300 p-2 rounded-md">शिक्षकहरू</a>
                <a href="news.php" class="text-white hover:text-blue-200 transition duration-300 p-2 rounded-md">सूचना तथा समाचार</a>
                <a href="admission.php" class="text-white hover:text-blue-200 transition duration-300 p-2 rounded-md">भर्ना</a>
                <a href="contact.php" class="text-white hover:text-blue-200 transition duration-300 p-2 rounded-md">सम्पर्क</a>
            </div>
            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button id="mobile-menu-button" class="text-white text-2xl focus:outline-none">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </nav>

    <!-- Mobile Menu Overlay -->
    <div id="mobile-menu-overlay" class="mobile-menu-overlay"></div>

    <!-- Mobile Menu Sidebar -->
    <div id="mobile-menu" class="mobile-menu">
        <div class="flex justify-end mb-4">
            <button id="close-mobile-menu" class="text-gray-600 text-2xl focus:outline-none">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <nav class="flex flex-col space-y-4">
            <a href="index.php" class="text-gray-800 hover:bg-blue-100 p-3 rounded-md transition duration-300">गृहपृष्ठ</a>
            <a href="about.php" class="text-gray-800 hover:bg-blue-100 p-3 rounded-md transition duration-300">हाम्रो बारेमा</a>
            <a href="programs.php" class="text-gray-800 hover:bg-blue-100 p-3 rounded-md transition duration-300">कार्यक्रमहरू</a>
            <a href="teachers.php" class="text-gray-800 hover:bg-blue-100 p-3 rounded-md transition duration-300">शिक्षकहरू</a>
            <a href="news.php" class="text-gray-800 hover:bg-blue-100 p-3 rounded-md transition duration-300">सूचना तथा समाचार</a>
            <a href="admission.php" class="text-gray-800 hover:bg-blue-100 p-3 rounded-md transition duration-300">भर्ना</a>
            <a href="contact.php" class="text-gray-800 hover:bg-blue-100 p-3 rounded-md transition duration-300">सम्पर्क</a>
            <a href="admin/admin_login.php" class="text-gray-800 hover:bg-blue-100 p-3 rounded-md transition duration-300">एडमिन लगइन</a>
        </nav>
    </div>
