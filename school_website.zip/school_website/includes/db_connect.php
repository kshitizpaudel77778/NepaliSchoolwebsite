<?php
// डेटाबेस जडान सेटिङहरू
$servername = "localhost"; // तपाईंको डेटाबेस सर्भर नाम
$username = "root"; // तपाईंको डेटाबेस प्रयोगकर्ता नाम
$password = ""; // तपाईंको डेटाबेस पासवर्ड
$dbname = "school_db"; // तपाईंको डेटाबेस नाम

// MySQLi वस्तु-उन्मुख तरिका प्रयोग गरेर जडान सिर्जना गर्नुहोस्
$conn = new mysqli($servername, $username, $password, $dbname);

// जडान जाँच गर्नुहोस्
if ($conn->connect_error) {
    die("जडान असफल: " . $conn->connect_error);
}
// वैकल्पिक: जडान सफल भएको सन्देश (विकासको लागि मात्र)
// echo "डेटाबेस सफलतापूर्वक जडान भयो!";
?>
