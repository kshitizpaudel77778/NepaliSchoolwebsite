    <footer class="bg-gray-800 text-white p-6 mt-10 shadow-inner">
        <div class="container mx-auto text-center">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                <div>
                    <h3 class="text-xl font-semibold mb-4 text-blue-300">हाम्रो विद्यालय</h3>
                    <p class="text-gray-400">गुणस्तरीय शिक्षा प्रदान गर्न प्रतिबद्ध।</p>
                </div>
                <div>
                    <h3 class="text-xl font-semibold mb-4 text-blue-300">द्रुत लिङ्कहरू</h3>
                    <ul class="space-y-2">
                        <li><a href="index.php" class="text-gray-400 hover:text-white transition duration-300">गृहपृष्ठ</a></li>
                        <li><a href="about.php" class="text-gray-400 hover:text-white transition duration-300">हाम्रो बारेमा</a></li>
                        <li><a href="programs.php" class="text-gray-400 hover:text-white transition duration-300">शैक्षिक कार्यक्रमहरू</a></li>
                        <li><a href="contact.php" class="text-gray-400 hover:text-white transition duration-300">सम्पर्क</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="text-xl font-semibold mb-4 text-blue-300">सम्पर्कमा रहनुहोस्</h3>
                    <p class="text-gray-400">ठेगाना: विद्यालय मार्ग, काठमाडौं, नेपाल</p>
                    <p class="text-gray-400">फोन: +९७७ १ २३४५६७८</p>
                    <p class="text-gray-400">इमेल: info@ourschool.edu.np</p>
                    <div class="flex justify-center space-x-4 mt-4">
                        <a href="#" class="text-gray-400 hover:text-white transition duration-300"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white transition duration-300"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white transition duration-300"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-700 pt-6 mt-6 text-gray-500">
                &copy; <?php echo date("Y"); ?> हाम्रो विद्यालय। सबै अधिकार सुरक्षित।
            </div>
        </div>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>
