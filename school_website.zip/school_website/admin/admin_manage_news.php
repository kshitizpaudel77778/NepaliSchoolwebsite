<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: admin_login.php");
    exit;
}

include '../includes/db_connect.php';

$message = "";
$message_type = "";
$edit_mode = false;
$news_id_to_edit = null;
$news_title = "";
$news_content = "";
$news_image_url = "";

// समाचार थप्नुहोस्
if (isset($_POST['add_news'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $image_url = $conn->real_escape_string($_POST['image_url']);

    $sql = "INSERT INTO news (title, content, image_url) VALUES ('$title', '$content', '$image_url')";
    if ($conn->query($sql) === TRUE) {
        $message = "समाचार सफलतापूर्वक थपियो!";
        $message_type = "success";
    } else {
        $message = "त्रुटि: " . $sql . "<br>" . $conn->error;
        $message_type = "error";
    }
}

// समाचार सम्पादनका लागि डाटा लोड गर्नुहोस्
if (isset($_GET['edit'])) {
    $news_id_to_edit = $conn->real_escape_string($_GET['edit']);
    $sql = "SELECT * FROM news WHERE id = $news_id_to_edit";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $news_title = $row['title'];
        $news_content = $row['content'];
        $news_image_url = $row['image_url'];
        $edit_mode = true;
    } else {
        $message = "सम्पादन गर्न समाचार फेला परेन।";
        $message_type = "error";
    }
}

// समाचार अपडेट गर्नुहोस्
if (isset($_POST['update_news'])) {
    $id = $conn->real_escape_string($_POST['news_id']);
    $title = $conn->real_escape_string($_POST['title']);
    $content = $conn->real_escape_string($_POST['content']);
    $image_url = $conn->real_escape_string($_POST['image_url']);

    $sql = "UPDATE news SET title = '$title', content = '$content', image_url = '$image_url' WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        $message = "समाचार सफलतापूर्वक अपडेट गरियो!";
        $message_type = "success";
        $edit_mode = false; // सम्पादन मोडबाट बाहिर निस्कनुहोस्
    } else {
        $message = "त्रुटि अपडेट गर्दै: " . $conn->error;
        $message_type = "error";
    }
}

// समाचार मेटाउनुहोस्
if (isset($_GET['delete'])) {
    $id = $conn->real_escape_string($_GET['delete']);
    $sql = "DELETE FROM news WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        $message = "समाचार सफलतापूर्वक मेटाइयो!";
        $message_type = "success";
    } else {
        $message = "त्रुटि मेटाउँदै: " . $conn->error;
        $message_type = "error";
    }
}

// सबै समाचारहरू ल्याउनुहोस्
$news_list_sql = "SELECT * FROM news ORDER BY date_posted DESC";
$news_list_result = $conn->query($news_list_sql);
?>
<!DOCTYPE html>
<html lang="ne">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>समाचार व्यवस्थापन - एडमिन</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f0f4f8; }
    </style>
</head>
<body class="bg-gray-100 text-gray-900">
    <nav class="bg-blue-800 p-4 shadow-md">
        <div class="container mx-auto flex justify-between items-center">
            <a href="admin_dashboard.php" class="text-white text-2xl font-bold rounded-md hover:text-blue-200 transition duration-300">एडमिन ड्यासबोर्ड</a>
            <div class="flex items-center space-x-4">
                <span class="text-white">स्वागत छ, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
                <a href="logout.php" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-300">
                    <i class="fas fa-sign-out-alt mr-2"></i> बाहिर निस्कनुहोस्
                </a>
            </div>
        </div>
    </nav>

    <main class="container mx-auto my-10 p-6 bg-white rounded-xl shadow-lg">
        <h1 class="text-4xl font-bold text-center text-blue-800 mb-8">सूचना तथा समाचार व्यवस्थापन</h1>

        <?php if ($message): ?>
            <div class="p-4 mb-6 rounded-md <?php echo $message_type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- समाचार थप्नुहोस् / सम्पादन फारम -->
        <section class="mb-10 p-6 bg-blue-50 rounded-lg shadow-md">
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">
                <?php echo $edit_mode ? 'समाचार सम्पादन गर्नुहोस्' : 'नयाँ समाचार थप्नुहोस्'; ?>
            </h2>
            <form action="admin_manage_news.php" method="POST" class="space-y-4">
                <?php if ($edit_mode): ?>
                    <input type="hidden" name="news_id" value="<?php echo htmlspecialchars($news_id_to_edit); ?>">
                <?php endif; ?>
                <div>
                    <label for="title" class="block text-gray-700 text-lg font-semibold mb-2">शीर्षक:</label>
                    <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($news_title); ?>" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
                <div>
                    <label for="content" class="block text-gray-700 text-lg font-semibold mb-2">सामग्री:</label>
                    <textarea id="content" name="content" rows="8" required
                              class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200"><?php echo htmlspecialchars($news_content); ?></textarea>
                </div>
                <div>
                    <label for="image_url" class="block text-gray-700 text-lg font-semibold mb-2">छविको URL (वैकल्पिक):</label>
                    <input type="url" id="image_url" name="image_url" value="<?php echo htmlspecialchars($news_image_url); ?>"
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200"
                           placeholder="उदाहरण: https://example.com/image.jpg">
                </div>
                <div class="text-center">
                    <button type="submit" name="<?php echo $edit_mode ? 'update_news' : 'add_news'; ?>"
                            class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transform transition duration-300 ease-in-out hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300">
                        <?php echo $edit_mode ? 'समाचार अपडेट गर्नुहोस्' : 'समाचार थप्नुहोस्'; ?>
                    </button>
                    <?php if ($edit_mode): ?>
                        <a href="admin_manage_news.php" class="ml-4 bg-gray-500 hover:bg-gray-600 text-white font-bold py-3 px-8 rounded-full shadow-lg transform transition duration-300 ease-in-out hover:scale-105 focus:outline-none focus:ring-4 focus:ring-gray-300">
                            रद्द गर्नुहोस्
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </section>

        <!-- अवस्थित समाचारहरू -->
        <section>
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">अवस्थित समाचारहरू</h2>
            <?php if ($news_list_result->num_rows > 0): ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white rounded-lg shadow-md">
                        <thead>
                            <tr class="bg-gray-200 text-gray-700 uppercase text-sm leading-normal">
                                <th class="py-3 px-6 text-left">शीर्षक</th>
                                <th class="py-3 px-6 text-left">छवि</th>
                                <th class="py-3 px-6 text-left">प्रकाशित मिति</th>
                                <th class="py-3 px-6 text-center">कार्यहरू</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 text-sm font-light">
                            <?php while($row = $news_list_result->fetch_assoc()): ?>
                                <tr class="border-b border-gray-200 hover:bg-gray-100">
                                    <td class="py-3 px-6 text-left whitespace-nowrap"><?php echo htmlspecialchars($row['title']); ?></td>
                                    <td class="py-3 px-6 text-left">
                                        <img src="<?php echo htmlspecialchars($row['image_url']); ?>" alt="News Image" class="w-16 h-10 object-cover rounded-md" onerror="this.onerror=null;this.src='https://placehold.co/64x40/cccccc/333333?text=No+Img';">
                                    </td>
                                    <td class="py-3 px-6 text-left"><?php echo date("Y-m-d", strtotime($row['date_posted'])); ?></td>
                                    <td class="py-3 px-6 text-center">
                                        <a href="admin_manage_news.php?edit=<?php echo $row['id']; ?>" class="text-blue-600 hover:text-blue-800 mr-3">
                                            <i class="fas fa-edit"></i> सम्पादन
                                        </a>
                                        <a href="admin_manage_news.php?delete=<?php echo $row['id']; ?>" class="text-red-600 hover:text-red-800" onclick="return confirm('के तपाईं यो समाचार मेटाउन निश्चित हुनुहुन्छ?');">
                                            <i class="fas fa-trash-alt"></i> मेटाउनुहोस्
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-center text-gray-600">कुनै समाचार उपलब्ध छैन।</p>
            <?php endif; ?>
        </section>
    </main>

    <?php $conn->close(); ?>
</body>
</html>
