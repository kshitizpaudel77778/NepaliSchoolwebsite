<?php
session_start();
session_unset(); // सबै सत्र चरहरू हटाउनुहोस्
session_destroy(); // सत्र नष्ट गर्नुहोस्
header("Location: admin_login.php"); // लगइन पृष्ठमा रिडाइरेक्ट गर्नुहोस्
exit;
?>
