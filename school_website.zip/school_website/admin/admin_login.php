<?php
session_start();
// db_connect.php फाइल समावेश गर्नुहोस्
include '../includes/db_connect.php';

$message = ""; // लगइन प्रयास पछि प्रयोगकर्तालाई देखाउन सन्देश

// यदि फारम POST विधि प्रयोग गरेर पेश गरिएको छ भने
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // प्रयोगकर्ता नाम र पासवर्ड फारमबाट प्राप्त गर्नुहोस् र SQL इन्जेक्सनबाट बच्न सुरक्षित गर्नुहोस्
    $username = $conn->real_escape_string($_POST['username']);
    $password = $conn->real_escape_string($_POST['password']);

    // डेटाबेसमा प्रयोगकर्ता नाम जाँच गर्नुहोस्
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    // यदि प्रयोगकर्ता फेला पर्यो भने
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // ह्यास गरिएको पासवर्ड password_verify() प्रयोग गरेर जाँच गर्नुहोस्
        // नोट: 'admin123' को लागि ह्यास गरिएको पासवर्ड डेटाबेस स्कीमामा पूर्वनिर्धारित रूपमा सेट गरिएको छ।
        if (password_verify($password, $row['password'])) {
            // लगइन सफल भएमा सत्र चरहरू सेट गर्नुहोस्
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role']; // यदि तपाईंको प्रणालीमा विभिन्न भूमिकाहरू छन् भने

            // एडमिन ड्यासबोर्डमा रिडाइरेक्ट गर्नुहोस्
            header("Location: admin_dashboard.php");
            exit; // रिडाइरेक्ट पछि स्क्रिप्टको कार्यान्वयन रोक्न महत्त्वपूर्ण
        } else {
            // गलत पासवर्ड
            $message = "गलत प्रयोगकर्ता नाम वा पासवर्ड।";
        }
    } else {
        // प्रयोगकर्ता नाम फेला परेन
        $message = "गलत प्रयोगकर्ता नाम वा पासवर्ड।";
    }
    $conn->close(); // डेटाबेस जडान बन्द गर्नुहोस्
}
?>
<!DOCTYPE html>
<html lang="ne">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>एडमिन लगइन - हाम्रो विद्यालय</title>
    <!-- Tailwind CSS CDN समावेश गर्नुहोस् -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts - Inter समावेश गर्नुहोस् -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        /* शरीरको लागि आधारभूत स्टाइलिंग */
        body {
            font-family: 'Inter', sans-serif;
            background-color: #e2e8f0; /* हल्का खैरो पृष्ठभूमि */
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-200 p-4">
    <div class="bg-white rounded-xl shadow-lg p-8 w-full max-w-md">
        <h1 class="text-3xl font-bold text-center text-blue-800 mb-6">एडमिन लगइन</h1>

        <?php if ($message): // यदि कुनै सन्देश छ भने, यसलाई प्रदर्शन गर्नुहोस् ?>
            <div class="p-4 mb-4 rounded-md bg-red-100 text-red-700">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form action="admin_login.php" method="POST" class="space-y-6">
            <div>
                <label for="username" class="block text-gray-700 text-lg font-semibold mb-2">प्रयोगकर्ता नाम:</label>
                <input type="text" id="username" name="username" required
                       class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
            </div>
            <div>
                <label for="password" class="block text-gray-700 text-lg font-semibold mb-2">पासवर्ड:</label>
                <input type="password" id="password" name="password" required
                       class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
            </div>
            <div class="text-center">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transform transition duration-300 ease-in-out hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300">
                    लगइन गर्नुहोस्
                </button>
            </div>
        </form>
    </div>
</body>
</html>
