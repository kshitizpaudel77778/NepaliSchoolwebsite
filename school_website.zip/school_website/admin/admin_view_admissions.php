<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: admin_login.php");
    exit;
}

include '../includes/db_connect.php';

$message = "";
$message_type = "";

// भर्ना मेटाउनुहोस्
if (isset($_GET['delete'])) {
    $id = $conn->real_escape_string($_GET['delete']);
    $sql = "DELETE FROM admissions WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        $message = "भर्ना आवेदन सफलतापूर्वक मेटाइयो!";
        $message_type = "success";
    } else {
        $message = "त्रुटि मेटाउँदै: " . $conn->error;
        $message_type = "error";
    }
}

// सबै भर्ना आवेदनहरू ल्याउनुहोस्
$admissions_sql = "SELECT * FROM admissions ORDER BY submission_date DESC";
$admissions_result = $conn->query($admissions_sql);
?>
<!DOCTYPE html>
<html lang="ne">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>भर्ना विवरण - एडमिन</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f0f4f8; }
    </style>
</head>
<body class="bg-gray-100 text-gray-900">
    <nav class="bg-blue-800 p-4 shadow-md">
        <div class="container mx-auto flex justify-between items-center">
            <a href="admin_dashboard.php" class="text-white text-2xl font-bold rounded-md hover:text-blue-200 transition duration-300">एडमिन ड्यासबोर्ड</a>
            <div class="flex items-center space-x-4">
                <span class="text-white">स्वागत छ, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
                <a href="logout.php" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-300">
                    <i class="fas fa-sign-out-alt mr-2"></i> बाहिर निस्कनुहोस्
                </a>
            </div>
        </div>
    </nav>

    <main class="container mx-auto my-10 p-6 bg-white rounded-xl shadow-lg">
        <h1 class="text-4xl font-bold text-center text-blue-800 mb-8">भर्ना विवरणहरू</h1>

        <?php if ($message): ?>
            <div class="p-4 mb-6 rounded-md <?php echo $message_type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if ($admissions_result->num_rows > 0): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-lg shadow-md">
                    <thead>
                        <tr class="bg-gray-200 text-gray-700 uppercase text-sm leading-normal">
                            <th class="py-3 px-6 text-left">पूरा नाम</th>
                            <th class="py-3 px-6 text-left">जन्म मिति</th>
                            <th class="py-3 px-6 text-left">लिङ्ग</th>
                            <th class="py-3 px-6 text-left">अभिभावकको नाम</th>
                            <th class="py-3 px-6 text-left">सम्पर्क</th>
                            <th class="py-3 px-6 text-left">इमेल</th>
                            <th class="py-3 px-6 text-left">कक्षा</th>
                            <th class="py-3 px-6 text-left">पेश गरेको मिति</th>
                            <th class="py-3 px-6 text-center">कार्यहरू</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 text-sm font-light">
                        <?php while($row = $admissions_result->fetch_assoc()): ?>
                            <tr class="border-b border-gray-200 hover:bg-gray-100">
                                <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['full_name']); ?></td>
                                <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['dob']); ?></td>
                                <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['gender']); ?></td>
                                <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['parent_name']); ?></td>
                                <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['parent_contact']); ?></td>
                                <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['email']); ?></td>
                                <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['grade_applying_for']); ?></td>
                                <td class="py-3 px-6 text-left"><?php echo date("Y-m-d", strtotime($row['submission_date'])); ?></td>
                                <td class="py-3 px-6 text-center">
                                    <a href="admin_view_admissions.php?delete=<?php echo $row['id']; ?>" class="text-red-600 hover:text-red-800" onclick="return confirm('के तपाईं यो भर्ना आवेदन मेटाउन निश्चित हुनुहुन्छ?');">
                                        <i class="fas fa-trash-alt"></i> मेटाउनुहोस्
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-center text-gray-600">कुनै भर्ना आवेदनहरू उपलब्ध छैनन्।</p>
        <?php endif; ?>
    </main>

    <?php $conn->close(); ?>
</body>
</html>
