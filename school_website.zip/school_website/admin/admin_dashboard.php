<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: admin_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ne">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>एडमिन ड्यासबोर्ड - हाम्रो विद्यालय</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts - Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f0f4f8; /* Light gray background */
        }
    </style>
</head>
<body class="bg-gray-100 text-gray-900">
    <!-- Admin Navbar -->
    <nav class="bg-blue-800 p-4 shadow-md">
        <div class="container mx-auto flex justify-between items-center">
            <a href="admin_dashboard.php" class="text-white text-2xl font-bold rounded-md hover:text-blue-200 transition duration-300">एडमिन ड्यासबोर्ड</a>
            <div class="flex items-center space-x-4">
                <span class="text-white">स्वागत छ, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
                <a href="logout.php" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-300">
                    <i class="fas fa-sign-out-alt mr-2"></i> बाहिर निस्कनुहोस्
                </a>
            </div>
        </div>
    </nav>

    <main class="container mx-auto my-10 p-6 bg-white rounded-xl shadow-lg">
        <h1 class="text-4xl font-bold text-center text-blue-800 mb-8">एडमिन ड्यासबोर्ड</h1>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <!-- Manage News Card -->
            <div class="bg-blue-50 p-6 rounded-lg shadow-md flex flex-col items-center text-center hover:shadow-xl transition-shadow duration-300">
                <div class="text-blue-600 text-5xl mb-4">
                    <i class="fas fa-newspaper"></i>
                </div>
                <h2 class="text-2xl font-semibold text-blue-700 mb-3">सूचना तथा समाचार व्यवस्थापन</h2>
                <p class="text-gray-700 mb-4">नयाँ समाचार थप्नुहोस्, अवस्थित समाचार सम्पादन गर्नुहोस् वा मेटाउनुहोस्।</p>
                <a href="admin_manage_news.php" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-full shadow-md transition duration-300">
                    व्यवस्थापन गर्नुहोस् <i class="fas fa-arrow-right ml-2"></i>
                </a>
            </div>

            <!-- View Admissions Card -->
            <div class="bg-green-50 p-6 rounded-lg shadow-md flex flex-col items-center text-center hover:shadow-xl transition-shadow duration-300">
                <div class="text-green-600 text-5xl mb-4">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <h2 class="text-2xl font-semibold text-green-700 mb-3">भर्ना विवरण हेर्नुहोस्</h2>
                <p class="text-gray-700 mb-4">पेश गरिएका भर्ना फारमहरू हेर्नुहोस् र व्यवस्थापन गर्नुहोस्।</p>
                <a href="admin_view_admissions.php" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-full shadow-md transition duration-300">
                    हेर्नुहोस् <i class="fas fa-arrow-right ml-2"></i>
                </a>
            </div>

            <!-- Manage Slideshow Images Card -->
            <div class="bg-purple-50 p-6 rounded-lg shadow-md flex flex-col items-center text-center hover:shadow-xl transition-shadow duration-300">
                <div class="text-purple-600 text-5xl mb-4">
                    <i class="fas fa-images"></i>
                </div>
                <h2 class="text-2xl font-semibold text-purple-700 mb-3">स्लाइड शो छविहरू व्यवस्थापन</h2>
                <p class="text-gray-700 mb-4">गृहपृष्ठ स्लाइड शोका लागि छविहरू थप्नुहोस्, सम्पादन गर्नुहोस् वा मेटाउनुहोस्।</p>
                <a href="admin_manage_slides.php" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded-full shadow-md transition duration-300">
                    व्यवस्थापन गर्नुहोस् <i class="fas fa-arrow-right ml-2"></i>
                </a>
            </div>
        </div>
    </main>

    <?php include '../includes/footer.php'; // Relative path to main footer ?>
</body>
</html>
