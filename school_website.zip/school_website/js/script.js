document.addEventListener('DOMContentLoaded', function() {
    // स्लाइड शो कार्यक्षमता
    let slideIndex = 1; // 1 बाट सुरु गर्नुहोस् ताकि पहिलो स्लाइड सुरुमा देखियोस्
    showSlides();

    function showSlides() {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("dot");

        // यदि कुनै स्लाइडहरू फेला परेनन् भने, स्लाइड शो चलाउनु पर्दैन
        if (slides.length === 0) {
            return;
        }

        // सबै स्लाइडहरू लुकाउनुहोस्
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }

        // सबै डटहरूबाट 'active-dot' क्लास हटाउनुहोस्
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active-dot", "");
        }

        // अर्को स्लाइडमा जानुहोस्
        slideIndex++;
        // यदि अन्तिम स्लाइडमा पुगियो भने, पहिलोमा फर्कनुहोस्
        if (slideIndex > slides.length) {
            slideIndex = 1;
        }

        // हालको स्लाइड र डट देखाउनुहोस्
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active-dot";

        // 5 सेकेन्ड पछि स्वतः स्लाइड परिवर्तन गर्नुहोस्
        setTimeout(showSlides, 5000);
    }

    // म्यानुअल स्लाइड परिवर्तनका लागि फंक्शन
    window.plusSlides = function(n) {
        showManualSlides(slideIndex += n);
    }

    // विशिष्ट स्लाइडमा जानका लागि फंक्शन
    window.currentSlide = function(n) {
        showManualSlides(slideIndex = n);
    }

    function showManualSlides(n) {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("dot");

        if (slides.length === 0) {
            return;
        }

        // स्लाइड सूचकांक समायोजन गर्नुहोस्
        if (n > slides.length) {
            slideIndex = 1;
        }
        if (n < 1) {
            slideIndex = slides.length;
        }

        // सबै स्लाइडहरू लुकाउनुहोस्
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }

        // सबै डटहरूबाट 'active-dot' क्लास हटाउनुहोस्
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active-dot", "");
        }

        // हालको स्लाइड र डट देखाउनुहोस्
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active-dot";
    }

    // मोबाइल मेनु टगल कार्यक्षमता
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const closeMobileMenuButton = document.getElementById('close-mobile-menu');
    const mobileMenu = document.getElementById('mobile-menu');
    const mobileMenuOverlay = document.getElementById('mobile-menu-overlay');

    if (mobileMenuButton) {
        mobileMenuButton.addEventListener('click', function() {
            mobileMenu.classList.add('open');
            mobileMenuOverlay.style.display = 'block';
        });
    }

    if (closeMobileMenuButton) {
        closeMobileMenuButton.addEventListener('click', function() {
            mobileMenu.classList.remove('open');
            mobileMenuOverlay.style.display = 'none';
        });
    }

    if (mobileMenuOverlay) {
        mobileMenuOverlay.addEventListener('click', function() {
            mobileMenu.classList.remove('open');
            mobileMenuOverlay.style.display = 'none';
        });
    }
});
