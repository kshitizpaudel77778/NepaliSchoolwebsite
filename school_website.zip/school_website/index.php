<?php
include 'includes/header.php';
include 'includes/db_connect.php'; // डेटाबेस जडान समावेश गर्नुहोस्
?>

    <!-- Hero Section -->
    <section class="hero-section text-white py-20 px-4">
        <div class="container mx-auto text-center">
            <h2 class="text-4xl sm:text-5xl md:text-6xl font-extrabold leading-tight mb-4 animate-fade-in-down">
                ज्ञान र उज्ज्वल भविष्यको लागि हाम्रो विद्यालय
            </h2>
            <p class="text-lg sm:text-xl md:text-2xl mb-8 animate-fade-in-up">
                हामी विद्यार्थीहरूलाई उत्कृष्टता र जीवनभर सिक्न प्रेरित गर्छौं।
            </p>
            <a href="admission.php" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transform transition duration-300 ease-in-out hover:scale-105 animate-bounce-in">
                अहिले भर्ना गर्नुहोस्
            </a>
        </div>
    </section>

    <!-- Welcome Message Section -->
    <section class="container mx-auto my-12 p-6 bg-white rounded-xl shadow-lg">
        <h2 class="text-3xl font-bold text-center text-blue-800 mb-6">हाम्रो विद्यालयमा स्वागत छ!</h2>
        <p class="text-gray-700 text-lg leading-relaxed text-center max-w-3xl mx-auto">
            हाम्रो विद्यालयले विद्यार्थीहरूको सर्वांगीण विकासमा ध्यान केन्द्रित गर्दछ। हामी गुणस्तरीय शिक्षा, नैतिक मूल्यमान्यता र व्यावहारिक सीपहरूको संयोजन प्रदान गर्दछौं ताकि हाम्रा विद्यार्थीहरूले भविष्यमा सफल जीवन बिताउन सकून्।
        </p>
    </section>

    <!-- Slideshow Section (Dynamic) -->
    <section class="container mx-auto my-12 p-6 bg-white rounded-xl shadow-lg">
        <h2 class="text-3xl font-bold text-center text-blue-800 mb-6">हाम्रो विद्यालयका झलकहरू</h2>
        <div class="slideshow-container">
            <?php
            $slides_sql = "SELECT image_url, caption FROM slideshow_images ORDER BY order_index ASC, date_added DESC";
            $slides_result = $conn->query($slides_sql);

            if ($slides_result->num_rows > 0) {
                $slide_count = 0;
                while($row = $slides_result->fetch_assoc()) {
                    $slide_count++;
                    // पहिलो स्लाइडलाई सुरुमा देखाउनको लागि स्टाइल थपिएको छ
                    $display_style = ($slide_count == 1) ? 'style="display: block;"' : '';
                    echo '<div class="mySlides fade" ' . $display_style . '>';
                    echo '<img src="' . htmlspecialchars($row["image_url"]) . '" alt="' . htmlspecialchars($row["caption"]) . '" class="w-full h-auto object-cover rounded-md" onerror="this.onerror=null;this.src=\'https://placehold.co/800x400/cccccc/333333?text=No+Image\';">';
                    echo '<div class="text-center p-4 text-gray-700">' . htmlspecialchars($row["caption"]) . '</div>';
                    echo '</div>';
                }
            } else {
                // यदि कुनै स्लाइडहरू छैनन् भने पूर्वनिर्धारित प्लेसहोल्डर देखाउनुहोस्
                echo '<div class="mySlides fade" style="display: block;">'; // Default display for placeholder
                echo '<img src="https://placehold.co/800x400/cccccc/333333?text=No+Slides+Yet" alt="No Slides Available" class="w-full h-auto object-cover rounded-md">';
                echo '<div class="text-center p-4 text-gray-700">कुनै स्लाइडहरू उपलब्ध छैनन्।</div>';
                echo '</div>';
                $slide_count = 1; // स्लाइड शो JavaScript चलाउनका लागि न्यूनतम १ स्लाइड सेट गर्नुहोस्
            }
            ?>

            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>
        </div>
        <div style="text-align:center" class="mt-4">
            <?php
            // स्लाइडहरूको संख्याको आधारमा डटहरू सिर्जना गर्नुहोस्
            for ($i = 1; $i <= $slide_count; $i++) {
                echo '<span class="dot" onclick="currentSlide(' . $i . ')"></span>';
            }
            ?>
        </div>
    </section>

    <!-- Latest News Section (Dynamic) -->
    <section class="container mx-auto my-12 p-6 bg-white rounded-xl shadow-lg">
        <h2 class="text-3xl font-bold text-center text-blue-800 mb-6">नवीनतम सूचना तथा समाचार</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php
            $sql = "SELECT id, title, SUBSTRING(content, 1, 150) as content_snippet, image_url, date_posted FROM news ORDER BY date_posted DESC LIMIT 3";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '<div class="bg-gray-50 p-4 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">';
                    echo '<img src="' . htmlspecialchars($row["image_url"]) . '" alt="' . htmlspecialchars($row["title"]) . '" class="w-full h-48 object-cover rounded-md mb-4" onerror="this.onerror=null;this.src=\'https://placehold.co/400x200/cccccc/333333?text=No+Image\';">';
                    echo '<h3 class="text-xl font-semibold text-blue-700 mb-2">' . htmlspecialchars($row["title"]) . '</h3>';
                    echo '<p class="text-gray-600 text-sm mb-3">' . htmlspecialchars($row["content_snippet"]) . '...</p>';
                    echo '<p class="text-gray-500 text-xs mb-3">प्रकाशित मिति: ' . date("Y-m-d", strtotime($row["date_posted"])) . '</p>';
                    echo '<a href="news.php?id=' . $row["id"] . '" class="text-blue-600 hover:underline font-medium">थप पढ्नुहोस् <i class="fas fa-arrow-right text-sm ml-1"></i></a>';
                    echo '</div>';
                }
            } else {
                echo '<p class="text-center text-gray-600 col-span-full">कुनै समाचार उपलब्ध छैन।</p>';
            }
            ?>
        </div>
        <div class="text-center mt-8">
            <a href="news.php" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-6 rounded-full shadow-md transition duration-300">सबै समाचार हेर्नुहोस्</a>
        </div>
    </section>

<?php
$conn->close(); // डेटाबेस जडान बन्द गर्नुहोस्
include 'includes/footer.php';
?>
