<?php include 'includes/header.php'; ?>

    <main class="container mx-auto my-10 p-6 bg-white rounded-xl shadow-lg">
        <h1 class="text-4xl font-bold text-center text-blue-800 mb-8">हाम्रो बारेमा</h1>

        <section class="mb-10">
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">इतिहास</h2>
            <div class="flex flex-col md:flex-row items-center md:space-x-8">
                <img src="https://placehold.co/400x250/E0F2F7/000000?text=School+History" alt="School History" class="w-full md:w-1/2 rounded-lg shadow-md mb-6 md:mb-0">
                <p class="text-gray-700 text-lg leading-relaxed">
                    हाम्रो विद्यालय सन् २००० मा स्थापित भएको थियो, जसको मुख्य उद्देश्य यस क्षेत्रका बालबालिकाहरूलाई गुणस्तरीय शिक्षा प्रदान गर्नु थियो। सानो सुरुवातबाट, हामीले निरन्तर प्रगति गर्दै आएका छौं र आज हामी उत्कृष्टताको प्रतीक बनेका छौं। हामीले हजारौं विद्यार्थीहरूलाई शिक्षित गरेका छौं जसले विभिन्न क्षेत्रमा सफलता हासिल गरेका छन्।
                </p>
            </div>
        </section>

        <section class="mb-10">
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">लक्ष्य</h2>
            <ul class="list-disc list-inside text-gray-700 text-lg leading-relaxed space-y-3">
                <li>विद्यार्थीहरूमा नैतिक मूल्यमान्यता र सामाजिक उत्तरदायित्वको भावना विकास गर्ने।</li>
                <li>आधुनिक शैक्षिक प्रविधि र विधिहरू प्रयोग गरी शिक्षण प्रक्रियालाई प्रभावकारी बनाउने।</li>
                <li>विद्यार्थीहरूलाई रचनात्मक, आलोचनात्मक र समस्या समाधान गर्ने क्षमता विकास गर्न प्रोत्साहन गर्ने।</li>
                <li>एक सुरक्षित, समावेशी र प्रेरणादायक सिकाइ वातावरण प्रदान गर्ने।</li>
            </ul>
        </section>

        <section>
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">उद्देश्य</h2>
            <ul class="list-disc list-inside text-gray-700 text-lg leading-relaxed space-y-3">
                <li>प्रत्येक विद्यार्थीको व्यक्तिगत क्षमतालाई चिन्न र त्यसलाई निखार्न मद्दत गर्ने।</li>
                <li>शैक्षिक, खेलकुद र अतिरिक्त क्रियाकलापहरूमा सन्तुलन कायम गरी सर्वांगीण विकास सुनिश्चित गर्ने।</li>
                <li>राष्ट्रिय तथा अन्तर्राष्ट्रिय स्तरमा प्रतिस्पर्धा गर्न सक्ने नागरिक तयार गर्ने।</li>
                <li>समुदायसँगको सहकार्यलाई सुदृढ गर्दै शैक्षिक गुणस्तर अभिवृद्धि गर्ने।</li>
            </ul>
        </section>
    </main>

<?php include 'includes/footer.php'; ?>
