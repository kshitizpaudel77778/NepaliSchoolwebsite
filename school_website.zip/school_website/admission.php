<?php
include 'includes/header.php';
include 'includes/db_connect.php';

$message = "";
$message_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // फारम डाटा भेरिएबलमा सुरक्षित गर्नुहोस्
    $full_name = $conn->real_escape_string($_POST['full_name']);
    $dob = $conn->real_escape_string($_POST['dob']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $parent_name = $conn->real_escape_string($_POST['parent_name']);
    $parent_contact = $conn->real_escape_string($_POST['parent_contact']);
    $email = $conn->real_escape_string($_POST['email']);
    $address = $conn->real_escape_string($_POST['address']);
    $grade_applying_for = $conn->real_escape_string($_POST['grade_applying_for']);
    $previous_school = $conn->real_escape_string($_POST['previous_school']);
    $message_text = $conn->real_escape_string($_POST['message']);

    // SQL क्वेरी तयार गर्नुहोस्
    $sql = "INSERT INTO admissions (full_name, dob, gender, parent_name, parent_contact, email, address, grade_applying_for, previous_school, message)
            VALUES ('$full_name', '$dob', '$gender', '$parent_name', '$parent_contact', '$email', '$address', '$grade_applying_for', '$previous_school', '$message_text')";

    if ($conn->query($sql) === TRUE) {
        $message = "तपाईंको भर्ना आवेदन सफलतापूर्वक पेश गरिएको छ। हामी छिट्टै तपाईंसँग सम्पर्क गर्नेछौं।";
        $message_type = "success";
    } else {
        $message = "त्रुटि: " . $sql . "<br>" . $conn->error;
        $message_type = "error";
    }
}
$conn->close();
?>

    <main class="container mx-auto my-10 p-6 bg-white rounded-xl shadow-lg">
        <h1 class="text-4xl font-bold text-center text-blue-800 mb-8">भर्ना फारम</h1>

        <?php if ($message): ?>
            <div class="p-4 mb-6 rounded-md <?php echo $message_type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form action="admission.php" method="POST" class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="full_name" class="block text-gray-700 text-lg font-semibold mb-2">पूरा नाम:</label>
                    <input type="text" id="full_name" name="full_name" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
                <div>
                    <label for="dob" class="block text-gray-700 text-lg font-semibold mb-2">जन्म मिति:</label>
                    <input type="date" id="dob" name="dob" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="gender" class="block text-gray-700 text-lg font-semibold mb-2">लिङ्ग:</label>
                    <select id="gender" name="gender" required
                            class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                        <option value="">लिङ्ग छान्नुहोस्</option>
                        <option value="पुरुष">पुरुष</option>
                        <option value="महिला">महिला</option>
                        <option value="अन्य">अन्य</option>
                    </select>
                </div>
                <div>
                    <label for="parent_name" class="block text-gray-700 text-lg font-semibold mb-2">अभिभावकको नाम:</label>
                    <input type="text" id="parent_name" name="parent_name" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="parent_contact" class="block text-gray-700 text-lg font-semibold mb-2">अभिभावकको सम्पर्क नम्बर:</label>
                    <input type="tel" id="parent_contact" name="parent_contact" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
                <div>
                    <label for="email" class="block text-gray-700 text-lg font-semibold mb-2">इमेल:</label>
                    <input type="email" id="email" name="email" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
            </div>

            <div>
                <label for="address" class="block text-gray-700 text-lg font-semibold mb-2">ठेगाना:</label>
                <textarea id="address" name="address" rows="3" required
                          class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200"></textarea>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="grade_applying_for" class="block text-gray-700 text-lg font-semibold mb-2">कुन कक्षाको लागि आवेदन दिँदै हुनुहुन्छ?</label>
                    <input type="text" id="grade_applying_for" name="grade_applying_for" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
                <div>
                    <label for="previous_school" class="block text-gray-700 text-lg font-semibold mb-2">अघिल्लो विद्यालय (यदि छ भने):</label>
                    <input type="text" id="previous_school" name="previous_school"
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
            </div>

            <div>
                <label for="message" class="block text-gray-700 text-lg font-semibold mb-2">अतिरिक्त सन्देश (वैकल्पिक):</label>
                <textarea id="message" name="message" rows="4"
                          class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200"></textarea>
            </div>

            <div class="text-center">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transform transition duration-300 ease-in-out hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300">
                    आवेदन पेश गर्नुहोस्
                </button>
            </div>
        </form>
    </main>

<?php include 'includes/footer.php'; ?>
