<?php include 'includes/header.php'; ?>

    <main class="container mx-auto my-10 p-6 bg-white rounded-xl shadow-lg">
        <h1 class="text-4xl font-bold text-center text-blue-800 mb-8">हामीलाई सम्पर्क गर्नुहोस्</h1>

        <section class="grid grid-cols-1 md:grid-cols-2 gap-10 mb-10">
            <!-- Contact Information -->
            <div>
                <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">सम्पर्क विवरण</h2>
                <div class="space-y-4 text-gray-700 text-lg">
                    <p><i class="fas fa-map-marker-alt text-blue-600 mr-3"></i> **ठेगाना:** विद्यालय मार्ग, काठमाडौं, नेपाल</p>
                    <p><i class="fas fa-phone-alt text-blue-600 mr-3"></i> **फोन:** +९७७ १ २३४५६७८</p>
                    <p><i class="fas fa-envelope text-blue-600 mr-3"></i> **इमेल:** info@ourschool.edu.np</p>
                    <p><i class="fas fa-clock text-blue-600 mr-3"></i> **कार्यालय समय:** आइतबार - शुक्रबार, बिहान १०:०० बजे - बेलुका ५:०० बजे</p>
                </div>
                <div class="mt-6">
                    <h3 class="text-2xl font-semibold text-blue-700 mb-3">हामीलाई सामाजिक सञ्जालमा पछ्याउनुहोस्</h3>
                    <div class="flex space-x-6 text-2xl">
                        <a href="#" class="text-blue-600 hover:text-blue-800 transition duration-300"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-blue-400 hover:text-blue-600 transition duration-300"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-pink-500 hover:text-pink-700 transition duration-300"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-red-600 hover:text-red-800 transition duration-300"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>

            <!-- Google Map Placeholder -->
            <div>
                <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">हाम्रो स्थान</h2>
                <div class="bg-gray-200 rounded-lg shadow-md overflow-hidden" style="height: 400px;">
                    <!-- Replace with your actual Google Map embed code -->
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12534.56789!2d85.3239599!3d27.7172453!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDQzJzAyLjEiTiA4NcKwMTknMjYuMiJF!5e0!3m2!1sen!2snp!4v1678901234567!5m2!1sen!2snp"
                            width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    <!-- Example placeholder for map: -->
                    <!-- <img src="https://placehold.co/600x400/D1E9FF/000000?text=Google+Map+Placeholder" alt="Map Location" class="w-full h-full object-cover"> -->
                </div>
            </div>
        </section>

        <section>
            <h2 class="text-3xl font-semibold text-blue-700 mb-4 border-b-2 border-blue-300 pb-2">हामीलाई सन्देश पठाउनुहोस्</h2>
            <form action="#" method="POST" class="space-y-6">
                <div>
                    <label for="name" class="block text-gray-700 text-lg font-semibold mb-2">नाम:</label>
                    <input type="text" id="name" name="name" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
                <div>
                    <label for="email" class="block text-gray-700 text-lg font-semibold mb-2">इमेल:</label>
                    <input type="email" id="email" name="email" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
                <div>
                    <label for="subject" class="block text-gray-700 text-lg font-semibold mb-2">विषय:</label>
                    <input type="text" id="subject" name="subject" required
                           class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200">
                </div>
                <div>
                    <label for="message" class="block text-gray-700 text-lg font-semibold mb-2">सन्देश:</label>
                    <textarea id="message" name="message" rows="6" required
                              class="w-full px-4 py-3 rounded-lg border-gray-300 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50 transition duration-200"></textarea>
                </div>
                <div class="text-center">
                    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transform transition duration-300 ease-in-out hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300">
                        सन्देश पठाउनुहोस्
                    </button>
                </div>
            </form>
        </section>
    </main>

<?php include 'includes/footer.php'; ?>
