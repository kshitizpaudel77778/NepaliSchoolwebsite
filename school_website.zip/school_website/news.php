<?php
include 'includes/header.php';
include 'includes/db_connect.php';
?>

    <main class="container mx-auto my-10 p-6 bg-white rounded-xl shadow-lg">
        <h1 class="text-4xl font-bold text-center text-blue-800 mb-8">सूचना तथा समाचारहरू</h1>

        <?php
        if (isset($_GET['id'])) {
            // एकल समाचार विवरण प्रदर्शन गर्नुहोस्
            $news_id = $conn->real_escape_string($_GET['id']);
            $sql = "SELECT * FROM news WHERE id = $news_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo '<div class="bg-gray-50 p-6 rounded-lg shadow-md">';
                echo '<img src="' . htmlspecialchars($row["image_url"]) . '" alt="' . htmlspecialchars($row["title"]) . '" class="w-full h-80 object-cover rounded-md mb-6" onerror="this.onerror=null;this.src=\'https://placehold.co/800x400/cccccc/333333?text=No+Image\';">';
                echo '<h2 class="text-3xl font-bold text-blue-700 mb-3">' . htmlspecialchars($row["title"]) . '</h2>';
                echo '<p class="text-gray-500 text-sm mb-4">प्रकाशित मिति: ' . date("Y-m-d H:i", strtotime($row["date_posted"])) . '</p>';
                echo '<div class="text-gray-700 text-lg leading-relaxed">' . nl2br(htmlspecialchars($row["content"])) . '</div>';
                echo '<div class="mt-6 text-center">';
                echo '<a href="news.php" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-6 rounded-full shadow-md transition duration-300"><i class="fas fa-arrow-left mr-2"></i> सबै समाचारमा फर्कनुहोस्</a>';
                echo '</div>';
                echo '</div>';
            } else {
                echo '<p class="text-center text-red-600 text-lg">समाचार फेला परेन।</p>';
            }
        } else {
            // सबै समाचार सूची प्रदर्शन गर्नुहोस्
            $sql = "SELECT id, title, SUBSTRING(content, 1, 200) as content_snippet, image_url, date_posted FROM news ORDER BY date_posted DESC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">';
                while($row = $result->fetch_assoc()) {
                    echo '<div class="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300">';
                    echo '<img src="' . htmlspecialchars($row["image_url"]) . '" alt="' . htmlspecialchars($row["title"]) . '" class="w-full h-48 object-cover rounded-md mb-4" onerror="this.onerror=null;this.src=\'https://placehold.co/400x200/cccccc/333333?text=No+Image\';">';
                    echo '<h3 class="text-xl font-semibold text-blue-700 mb-2">' . htmlspecialchars($row["title"]) . '</h3>';
                    echo '<p class="text-gray-600 text-sm mb-3">' . htmlspecialchars($row["content_snippet"]) . '...</p>';
                    echo '<p class="text-gray-500 text-xs mb-3">प्रकाशित मिति: ' . date("Y-m-d", strtotime($row["date_posted"])) . '</p>';
                    echo '<a href="news.php?id=' . $row["id"] . '" class="text-blue-600 hover:underline font-medium">थप पढ्नुहोस् <i class="fas fa-arrow-right text-sm ml-1"></i></a>';
                    echo '</div>';
                }
                echo '</div>';
            } else {
                echo '<p class="text-center text-gray-600 text-lg">कुनै समाचार उपलब्ध छैन।</p>';
            }
        }
        $conn->close();
        ?>
    </main>

<?php include 'includes/footer.php'; ?>
